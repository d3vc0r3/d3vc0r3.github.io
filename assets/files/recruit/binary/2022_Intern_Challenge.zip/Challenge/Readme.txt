## Environment
Windows 11 Version 10.0.22000.795

## How to run the challenge
> ParentMoniter.exe

## Description 
After run the challenge, you can interactive with the server.

Your goal is popping `calc.exe` !

Enjoy it :)