## Environment
Windows 11 Version 10.0.22621.1105

## How to run the challenge
> ParentMoniter.exe (Run as administrator)

## Description 
After run the challenge, you can interactive with the server.

Your goal is popping `calc.exe` !

Enjoy it :)